package kr.or.ksmart.dto;

public class Goods {
	private String g_code = null;
	private String m_id = null;
	private String g_name = null;
	private String g_cate = null;
	private String g_price = null;
	private String g_color = null;
	private String g_size = null;
	private String g_date = null;
	private String g_detail = null;
	
	public String getG_code() {
		return g_code;
	}
	public void setG_code(String g_code) {
		System.out.println(g_code+" <-- g_code setg_code Goods.java");
		this.g_code = g_code;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		System.out.println(m_id+" <-- m_id setM_id Goods.java");
		this.m_id = m_id;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		System.out.println(g_name+" <-- g_name setG_name Goods.java");
		this.g_name = g_name;
	}
	public String getG_cate() {
		return g_cate;
	}
	public void setG_cate(String g_cate) {
		System.out.println(g_cate+" <-- g_cate setG_cate Goods.java");
		this.g_cate = g_cate;
	}
	public String getG_price() {
		return g_price;
	}
	public void setG_price(String g_price) {
		System.out.println(g_price+" <-- g_price setG_price Goods.java");
		this.g_price = g_price;
	}
	public String getG_color() {
		return g_color;
	}
	public void setG_color(String g_color) {
		System.out.println(g_color+" <-- setG_color setG_color Goods.java");
		this.g_color = g_color;
	}
	public String getG_size() {
		return g_size;
	}
	public void setG_size(String g_size) {
		System.out.println(g_size+" <-- g_size setG_size Goods.java");
		this.g_size = g_size;
	}
	public String getG_date() {
		return g_date;
	}
	public void setG_date(String g_date) {
		System.out.println(g_date+" <-- g_date setG_date Goods.java");
		this.g_date = g_date;
	}
	public String getG_detail() {
		return g_detail;
	}
	public void setG_detail(String g_detail) {
		System.out.println(g_detail+" <-- g_detail setG_detail Goods.java");
		this.g_detail = g_detail;
	}
	
	
}
